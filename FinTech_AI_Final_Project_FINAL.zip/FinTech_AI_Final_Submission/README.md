# FinTech AI Technology Intelligence & Automation Platform

## Final Submission Package — HOPE AI Mentor

This is the consolidated final project artifact. It contains the executive React dashboard, FastAPI backend, ML pipeline/model, RAG knowledge base, synthetic FinTech datasets, Terraform infrastructure modules, architecture diagram and final report.

### Architecture
Technical Signal → ML Prediction → Cross-Domain Correlation → Customer/Business/Financial Impact → RAG Context → AI Recommendation → Human Approval → Governed Action → Audit/KPI

### Project Structure
```text
FinTech_AI_Final_Submission/
├── backend/
│   ├── main.py
│   └── requirements.txt
├── frontend/
│   ├── src/App.tsx
│   ├── src/index.css
│   ├── index.html
│   ├── package.json
│   ├── vite.config.ts
│   ├── tsconfig.json
│   └── .env.example
├── ml/
│   ├── train_incident_model.py
│   ├── incident_severity_model.pkl
│   ├── rag_engine.py
│   └── rag_query.py
├── data/
│   ├── transactions_50000.csv
│   ├── security_findings_2000.csv
│   ├── iam_events_10000.csv
│   ├── service_metrics_30days_5min.csv
│   ├── cloud_cost_12months.csv
│   └── historical_incidents_300.csv
├── knowledge_base/
├── infra/terraform/
├── architecture/final_architecture.png
└── docs/
    ├── Final_Project_Report.pdf
    ├── Final_Project_Report.docx
    └── Final_Project_Report.md
```

## Run Locally
### Backend
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r backend/requirements.txt
python -m uvicorn backend.main:app --reload
```
Open Swagger at `http://127.0.0.1:8000/docs`.

### Frontend
```bash
cd frontend
npm install
npm run dev
```
Open `http://localhost:5173`.

### ML
```bash
python ml/train_incident_model.py
```

### RAG
```bash
python ml/rag_engine.py
python ml/rag_query.py
```

## Core APIs
GET `/api/dashboard` · GET `/api/correlation` · GET `/api/security` · GET `/api/iam` · GET `/api/fraud` · GET `/api/aiops` · GET `/api/finops` · GET `/api/incidents` · POST `/api/predict` · POST `/api/copilot` · GET `/api/agents` · POST `/api/approval` · GET `/api/audit`

## Important POC Note
The datasets are synthetic. The supplied model is an engineering demonstration and not production evidence of model performance. Production deployment requires validated labels, stronger evaluation, model monitoring, RBAC/SSO, persistent audit storage, policy-as-code, secure secrets and controlled automation.

## Final integration fix
The final package includes a compatibility-safe `/api/approval` endpoint. The backend accepts both `approved: true/false` and the earlier `decision: APPROVED/REJECTED` request formats. The upgraded React dashboard sends `approved`, so the CTO Copilot approval flow and Governance/Audit section are aligned.
