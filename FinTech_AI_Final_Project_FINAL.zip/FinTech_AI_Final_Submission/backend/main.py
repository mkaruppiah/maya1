from pathlib import Path
from typing import Any, Dict, Optional
import json
import math
import pickle

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sklearn.ensemble import RandomForestClassifier

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
MODEL_PATH = ROOT / "ml" / "incident_severity_model.pkl"

app = FastAPI(title="FinTech AI Technology Intelligence API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

audit_log = []

class Incident(BaseModel):
    security_risk: float = Field(..., ge=0, le=10)
    iam_risk: float = Field(..., ge=0, le=10)
    latency: float = Field(..., ge=0)
    customer_impact: float = Field(..., ge=0, le=1)
    error_rate: float = Field(..., ge=0)

class CopilotRequest(BaseModel):
    question: str

class ApprovalRequest(BaseModel):
    # Supports both the original `decision` contract and the UI-friendly `approved` contract.
    approved: bool | None = None
    decision: str | None = None
    owner: str = "CTO"
    action: str = "AI recommendation"
    source: str = "CTO Copilot"


def read_csv(name: str) -> pd.DataFrame:
    path = DATA / name
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def clamp(v: float) -> float:
    return max(0.0, min(100.0, float(v)))


def risk_level(v: float) -> str:
    return "CRITICAL" if v >= 75 else "HIGH" if v >= 50 else "MEDIUM" if v >= 25 else "LOW"


def intelligence() -> Dict[str, Any]:
    sec = read_csv("security_findings_2000.csv")
    iam = read_csv("iam_events_10000.csv")
    tx = read_csv("transactions_50000.csv")
    metrics = read_csv("service_metrics_30days_5min.csv")
    costs = read_csv("cloud_cost_12months.csv")
    incidents = read_csv("historical_incidents_300.csv")

    security_risk = clamp((pd.to_numeric(sec["cvss"], errors="coerce").mean() * 8.0 if not sec.empty and "cvss" in sec else 55))
    if not sec.empty:
        security_risk = clamp(security_risk + sec.get("internet_exposed", pd.Series([0])).mean() * 12 + sec.get("production", pd.Series([0])).mean() * 8)
    iam_risk = clamp((iam["risk_label"].mean() * 100 if not iam.empty and pd.api.types.is_numeric_dtype(iam["risk_label"]) else 55))
    if not iam.empty:
        iam_risk = clamp(25 + iam.get("off_hours_access", pd.Series([0])).mean() * 20 + iam.get("new_location", pd.Series([0])).mean() * 20 + iam.get("new_device", pd.Series([0])).mean() * 15 + iam.get("failed_logins", pd.Series([0])).mean() * 2)
    fraud_risk = clamp((pd.to_numeric(tx.get("fraud_label", pd.Series([0])), errors="coerce").mean() * 100) if not tx.empty else 42)
    aiops_risk = 65
    if not metrics.empty:
        err = float(pd.to_numeric(metrics.get("error_rate_pct", pd.Series([2])), errors="coerce").mean()) / 100
        lat = float(pd.to_numeric(metrics.get("latency_ms", pd.Series([150])), errors="coerce").mean())
        aiops_risk = clamp(err * 600 + lat / 8)
    finops_risk = 25
    cloud_cost = float(pd.to_numeric(costs.get("actual_cost_usd", pd.Series([1223600])), errors="coerce").sum()) if not costs.empty else 1223600
    active_incidents = int(incidents.get("severity", pd.Series(dtype=str)).astype(str).str.upper().isin(["P1", "P2"]).sum()) if not incidents.empty else 0
    technology_risk = clamp(security_risk*.25 + iam_risk*.15 + fraud_risk*.20 + aiops_risk*.20 + finops_risk*.10 + 38*.10)
    return {
        "technology_risk": round(technology_risk, 1),
        "security_risk": round(security_risk, 1),
        "iam_risk": round(iam_risk, 1),
        "fraud_risk": round(fraud_risk, 1),
        "aiops_risk": round(aiops_risk, 1),
        "finops_risk": round(finops_risk, 1),
        "customer_impact": "High" if technology_risk >= 50 else "Medium",
        "business_impact": "High" if technology_risk >= 50 else "Medium",
        "dominant_risk": max({"Security":security_risk,"IAM":iam_risk,"Fraud":fraud_risk,"AIOps":aiops_risk,"FinOps":finops_risk}, key=lambda k: {"Security":security_risk,"IAM":iam_risk,"Fraud":fraud_risk,"AIOps":aiops_risk,"FinOps":finops_risk}[k]),
        "cto_attention": technology_risk >= 50,
        "security_findings": int((sec.get("severity", pd.Series(dtype=str)).astype(str).str.upper().isin(["CRITICAL","HIGH"]).sum())) if not sec.empty else 0,
        "total_security_findings": int(len(sec)) if not sec.empty else 0,
        "iam_risk_events": int(iam.get("risk_label", pd.Series(dtype=int)).sum()) if not iam.empty and pd.api.types.is_numeric_dtype(iam.get("risk_label")) else int(len(iam) * .33),
        "total_iam_events": int(len(iam)) if not iam.empty else 0,
        "fraud_cases": int(tx.get("fraud_label", pd.Series(dtype=int)).sum()) if not tx.empty and pd.api.types.is_numeric_dtype(tx.get("fraud_label")) else 0,
        "active_incidents": active_incidents,
        "cloud_cost": cloud_cost,
    }


def recommendation(i: Dict[str, Any]) -> str:
    dominant = i["dominant_risk"]
    if dominant == "Security":
        return "Prioritize internet-facing production security remediation, validate exploitability, and review privileged IAM exposure before executing containment."
    if dominant == "AIOps":
        return "Prioritize service reliability: investigate latency/error anomalies, identify the affected customer journey, and activate the incident runbook."
    if dominant == "IAM":
        return "Review anomalous identity activity, privileged access and sensitive resources; contain suspicious sessions through an approved response workflow."
    if dominant == "Fraud":
        return "Prioritize high-risk transaction clusters, validate device/IP signals and route suspicious activity through the fraud response process."
    return "Review cloud cost variance and right-size non-critical capacity while protecting business-critical workloads."

@app.get("/")
def root(): return {"name": app.title, "version": app.version}

@app.get("/health")
def health(): return {"status":"healthy", "service":"fintech-ai-platform"}

@app.get("/api/dashboard")
def dashboard():
    i = intelligence()
    return i

@app.get("/api/correlation")
def correlation():
    i = intelligence(); i["recommendation"] = recommendation(i); i["risk_level"] = risk_level(i["technology_risk"]); return i

@app.get("/api/security")
def security():
    i = intelligence(); return {"risk":i["security_risk"],"level":risk_level(i["security_risk"]),"findings":i["security_findings"],"recommendation":recommendation(i)}

@app.get("/api/iam")
def iam():
    i = intelligence(); return {"risk":i["iam_risk"],"level":risk_level(i["iam_risk"]),"events":i["iam_risk_events"]}

@app.get("/api/fraud")
def fraud():
    i = intelligence(); return {"risk":i["fraud_risk"],"level":risk_level(i["fraud_risk"]),"cases":i["fraud_cases"]}

@app.get("/api/aiops")
def aiops():
    i = intelligence(); return {"risk":i["aiops_risk"],"level":risk_level(i["aiops_risk"]),"recommendation":recommendation(i)}

@app.get("/api/finops")
def finops():
    i = intelligence(); return {"risk":i["finops_risk"],"cloud_cost":i["cloud_cost"],"recommendation":recommendation(i)}

@app.get("/api/incidents")
def incidents():
    df = read_csv("historical_incidents_300.csv")
    if df.empty: return {"active_incidents":0,"p1":0,"p2":0,"p3":0}
    s=df.get("severity",pd.Series(dtype=str)).astype(str).str.upper()
    return {"active_incidents":int(len(df)),"p1":int((s=="P1").sum()),"p2":int((s=="P2").sum()),"p3":int((s=="P3").sum())}

@app.post("/api/predict")
def predict(x: Incident):
    score = clamp(x.security_risk*2.5 + x.iam_risk*2 + min(x.latency/10, 20) + x.customer_impact*20 + min(x.error_rate*150, 15))
    severity = "P1" if score >= 70 else "P2" if score >= 50 else "P3" if score >= 30 else "P4"
    return {"predicted_severity":severity,"risk_score":round(score,2),"risk_level":risk_level(score),"customer_impact":"High" if x.customer_impact>=.5 else "Medium","cto_attention":score>=50,"recommended_action":"Activate incident runbook and obtain human approval for consequential remediation."}

@app.post("/api/copilot")
def copilot(req: CopilotRequest):
    i=correlation()
    return {"executive_summary":f"{i['dominant_risk']} is the dominant technology risk at {i['technology_risk']}/100. The platform recommends prioritizing the highest-impact control path before other optimization work.","recommendation":i["recommendation"],"dominant_risk":i["dominant_risk"],"technology_risk":i["technology_risk"],"cto_attention":i["cto_attention"],"human_approval_required":True,"agent":"CTO Orchestrator","question":req.question}

@app.get("/api/agents")
def agents():
    return [{"name":n,"status":"Active","purpose":p} for n,p in [
        ("Security Agent","Threat and vulnerability triage"),("IAM Agent","Identity and privilege analysis"),("Fraud Agent","Transaction risk detection"),("AIOps Agent","Service anomaly correlation"),("FinOps Agent","Cloud cost intelligence"),("CTO Orchestrator","Cross-domain decision synthesis")]]

@app.post("/api/approval")
def approval(req: ApprovalRequest):
    if req.decision:
        decision = req.decision.upper()
    elif req.approved is not None:
        decision = "APPROVED" if req.approved else "REJECTED"
    else:
        raise HTTPException(status_code=422, detail="Provide either 'approved' or 'decision'.")
    event={"decision":decision,"owner":req.owner,"action":req.action,"source":req.source}
    audit_log.append(event)
    return {"status":"recorded","decision":event["decision"],"owner":event["owner"],"action":event["action"]}

@app.get("/api/audit")
def audit(): return audit_log
