import { useEffect, useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import "./index.css";

const API = "http://127.0.0.1:8000";

type AnyData = Record<string, any>;

const fallback = {
  dashboard: {
    technology_risk: 51.2,
    security_findings: 510,
    total_security_findings: 2000,
    iam_risk_events: 3309,
    total_iam_events: 10000,
    active_incidents: 258,
    fraud_cases: 361,
    cloud_cost: 1223600,
  },
  correlation: {
    technology_risk: 51.2,
    security_risk: 78,
    iam_risk: 55,
    fraud_risk: 42,
    aiops_risk: 65,
    finops_risk: 25,
    customer_impact: 38,
    dominant_risk: "Security",
    business_impact: "High",
    recommendation: "Prioritize internet-facing production security remediation and validate privileged IAM exposure.",
  },
};

async function getJson(path: string, options?: RequestInit) {
  const response = await fetch(`${API}${path}`, options);
  if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
  return response.json();
}

function riskLabel(score: number) {
  if (score >= 75) return "CRITICAL";
  if (score >= 50) return "HIGH";
  if (score >= 25) return "MEDIUM";
  return "LOW";
}

function riskClass(score: number) {
  if (score >= 75) return "critical";
  if (score >= 50) return "high";
  if (score >= 25) return "medium";
  return "low";
}

function Kpi({ title, value, sub, tone = "blue", icon }: { title: string; value: string; sub: string; tone?: string; icon: string }) {
  return (
    <div className={`kpi-card ${tone}`}>
      <div className="kpi-top">
        <span className="kpi-icon">{icon}</span>
        <span className="kpi-title">{title}</span>
      </div>
      <div className="kpi-value">{value}</div>
      <div className="kpi-sub">{sub}</div>
    </div>
  );
}

function SectionHeader({ eyebrow, title, desc }: { eyebrow: string; title: string; desc: string }) {
  return (
    <div className="section-head">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h2>{title}</h2>
        <p>{desc}</p>
      </div>
      <div className="section-line" />
    </div>
  );
}

function RiskPill({ score }: { score: number }) {
  return <span className={`risk-pill ${riskClass(score)}`}>{riskLabel(score)} · {score.toFixed(0)}</span>;
}

function App() {
  const [dashboard, setDashboard] = useState<AnyData>(fallback.dashboard);
  const [correlation, setCorrelation] = useState<AnyData>(fallback.correlation);
  const [agents, setAgents] = useState<any[]>([]);
  const [audit, setAudit] = useState<any[]>([]);
  const [copilot, setCopilot] = useState<any>(null);
  const [question, setQuestion] = useState("What should I worry about right now?");
  const [loading, setLoading] = useState(false);
  const [live, setLive] = useState(true);
  const [active, setActive] = useState("overview");
  const [toast, setToast] = useState("");

  const refresh = async () => {
    setLoading(true);
    try {
      const [d, c, a, au] = await Promise.all([
        getJson("/api/dashboard"),
        getJson("/api/correlation"),
        getJson("/api/agents"),
        getJson("/api/audit"),
      ]);
      setDashboard({ ...fallback.dashboard, ...d });
      setCorrelation({ ...fallback.correlation, ...c });
      setAgents(Array.isArray(a) ? a : a?.agents || []);
      setAudit(Array.isArray(au) ? au : au?.audit || []);
      setLive(true);
    } catch {
      setLive(false);
      setToast("Backend unavailable — showing demo intelligence.");
      setTimeout(() => setToast(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
    const timer = setInterval(refresh, 30000);
    return () => clearInterval(timer);
  }, []);

  const riskData = useMemo(() => [
    { name: "Security", value: Number(correlation.security_risk ?? 78) },
    { name: "AIOps", value: Number(correlation.aiops_risk ?? 65) },
    { name: "IAM", value: Number(correlation.iam_risk ?? 55) },
    { name: "Fraud", value: Number(correlation.fraud_risk ?? 42) },
    { name: "FinOps", value: Number(correlation.finops_risk ?? 25) },
  ], [correlation]);

  const trend = [
    { day: "Mon", risk: 44 },
    { day: "Tue", risk: 47 },
    { day: "Wed", risk: 45 },
    { day: "Thu", risk: 53 },
    { day: "Fri", risk: 49 },
    { day: "Sat", risk: 55 },
    { day: "Sun", risk: Number(correlation.technology_risk ?? 51.2) },
  ];

  const askCopilot = async () => {
    setLoading(true);
    try {
      const result = await getJson("/api/copilot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      });
      setCopilot(result);
      document.getElementById("copilot")?.scrollIntoView({ behavior: "smooth" });
    } catch {
      setCopilot({
        executive_summary: "Security is currently the dominant technology risk. Review exposed production assets and privileged IAM activity first.",
        recommendation: correlation.recommendation,
        dominant_risk: correlation.dominant_risk,
        technology_risk: correlation.technology_risk,
        cto_attention: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const approve = async (decision: "APPROVED" | "REJECTED") => {
    try {
      await getJson("/api/approval", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          approved: decision === "APPROVED",
          owner: "CTO",
          action: copilot?.recommendation || correlation.recommendation,
          source: "CTO Copilot",
        }),
      });
      setToast(`Decision ${decision.toLowerCase()} and recorded in governance audit.`);
      setTimeout(() => setToast(""), 3500);
      refresh();
    } catch {
      setToast("Approval endpoint unavailable. Check FastAPI.");
      setTimeout(() => setToast(""), 3000);
    }
  };

  const scrollTo = (id: string) => {
    setActive(id);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const security = Number(correlation.security_risk ?? 78);
  const iam = Number(correlation.iam_risk ?? 55);
  const fraud = Number(correlation.fraud_risk ?? 42);
  const aiops = Number(correlation.aiops_risk ?? 65);
  const finops = Number(correlation.finops_risk ?? 25);
  const tech = Number(correlation.technology_risk ?? dashboard.technology_risk ?? 51.2);

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">✦</div>
          <div>
            <div className="brand-kicker">FINTECH AI</div>
            <div className="brand-name">Technology<br />Intelligence</div>
          </div>
        </div>

        <div className="live-status">
          <span className={`pulse ${live ? "" : "offline"}`} />
          {live ? "LIVE INTELLIGENCE" : "DEMO MODE"}
        </div>

        <nav>
          {[
            ["overview", "⌂", "Executive Overview"],
            ["risk", "◈", "Risk Intelligence"],
            ["security", "△", "Security"],
            ["iam", "♙", "IAM Intelligence"],
            ["incidents", "◉", "Incident Intelligence"],
            ["aiops", "⌁", "AIOps"],
            ["finops", "▣", "FinOps"],
            ["cloud", "◇", "Cloud Intelligence"],
            ["decision", "✦", "AI Decision Center"],
            ["copilot", "◎", "CTO Copilot"],
            ["governance", "✓", "Governance & Audit"],
          ].map(([id, icon, label]) => (
            <button key={id} className={active === id ? "nav-item active" : "nav-item"} onClick={() => scrollTo(id)}>
              <span>{icon}</span>{label}
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="platform-dot" />
          <div>
            <strong>Platform Operational</strong>
            <small>AI Intelligence Platform v1.0</small>
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <div className="topbar-kicker">TECHNOLOGY COMMAND CENTER</div>
            <div className="topbar-title">Enterprise AI Decision Platform</div>
          </div>
          <div className="topbar-actions">
            <span className="last-sync">Last sync · just now</span>
            <button className="refresh-btn" onClick={refresh}>{loading ? "SYNCING..." : "↻ REFRESH"}</button>
          </div>
        </header>

        <section id="overview" className="hero section-anchor">
          <div className="hero-copy">
            <div className="hero-label"><span /> PREDICTIVE TECHNOLOGY INTELLIGENCE</div>
            <h1>FinTech AI<br /><em>Technology Intelligence</em></h1>
            <p>One decision layer connecting security, IAM, operations, fraud, cloud economics and AI governance.</p>
            <div className="hero-actions">
              <button className="primary-btn" onClick={() => scrollTo("decision")}>Open AI Decision Center →</button>
              <button className="ghost-btn" onClick={() => scrollTo("copilot")}>Ask CTO Copilot</button>
            </div>
          </div>

          <div className="hero-score">
            <div className="score-ring" style={{ ["--score" as any]: `${Math.min(100, tech)}%` }}>
              <div>
                <strong>{tech.toFixed(1)}</strong>
                <span>/100</span>
              </div>
            </div>
            <div className="score-caption">TECHNOLOGY RISK</div>
            <RiskPill score={tech} />
          </div>
        </section>

        <section className="kpi-grid">
          <Kpi title="Security Findings" value={`${dashboard.security_findings ?? 510}`} sub={`of ${dashboard.total_security_findings ?? 2000} monitored`} tone="red" icon="△" />
          <Kpi title="IAM Risk Events" value={`${dashboard.iam_risk_events ?? 3309}`} sub={`of ${dashboard.total_iam_events ?? 10000} events`} tone="purple" icon="♙" />
          <Kpi title="Active Incidents" value={`${dashboard.active_incidents ?? 258}`} sub="requiring response" tone="amber" icon="◉" />
          <Kpi title="Fraud Cases" value={`${dashboard.fraud_cases ?? 361}`} sub="detected by intelligence" tone="cyan" icon="◎" />
          <Kpi title="Cloud Cost" value={`$${((dashboard.cloud_cost ?? 1223600) / 1000).toFixed(1)}K`} sub="FinOps monitored spend" tone="green" icon="$" />
        </section>

        <section id="risk" className="section-anchor">
          <SectionHeader eyebrow="01 · RISK INTELLIGENCE" title="Cross-Domain Technology Risk" desc="Correlating security, identity, fraud, reliability and cloud economics into one executive posture." />
          <div className="two-col">
            <div className="panel chart-panel">
              <div className="panel-head"><div><span className="panel-label">RISK DOMAIN ANALYSIS</span><h3>Where should the CTO focus?</h3></div><RiskPill score={tech} /></div>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={riskData} margin={{ top: 15, right: 10, left: -15, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,.07)" vertical={false} />
                  <XAxis dataKey="name" stroke="#72809a" tick={{ fill: "#94a3b8", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 100]} stroke="#72809a" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: "#0b1425", border: "1px solid #24324a", borderRadius: 10, color: "#fff" }} />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]}>{riskData.map((r) => <Cell key={r.name} fill={r.value >= 75 ? "#fb7185" : r.value >= 50 ? "#f59e0b" : "#38bdf8"} />)}</Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="panel">
              <div className="panel-head"><div><span className="panel-label">RISK POSTURE</span><h3>Executive attention</h3></div><span className="attention">● CTO ATTENTION</span></div>
              <div className="risk-list">
                {[
                  ["Security", security, "Exposed production assets"],
                  ["AIOps", aiops, "Reliability / service health"],
                  ["IAM", iam, "Identity & privilege"],
                  ["Fraud", fraud, "Transaction anomalies"],
                  ["FinOps", finops, "Cost optimization"],
                ].map(([name, score, note]) => (
                  <div className="risk-row" key={String(name)}>
                    <div className="risk-name"><span>{name}</span><small>{note}</small></div>
                    <div className="mini-track"><span className={riskClass(Number(score))} style={{ width: `${score}%` }} /></div>
                    <strong>{Number(score).toFixed(0)}</strong>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="security" className="section-anchor">
          <SectionHeader eyebrow="02 · SECURITY" title="Security Intelligence" desc="Risk-ranked security posture with production exposure and customer-facing context." />
          <div className="signal-grid">
            <div className="signal-card critical-card"><span>CRITICAL EXPOSURE</span><strong>{Math.round(security)}%</strong><small>Security risk posture</small></div>
            <div className="signal-card"><span>FINDINGS</span><strong>{dashboard.security_findings ?? 510}</strong><small>High-risk findings detected</small></div>
            <div className="signal-card"><span>DECISION</span><strong>REMEDIATE</strong><small>Prioritize internet-facing production assets</small></div>
          </div>
        </section>

        <section id="iam" className="section-anchor">
          <SectionHeader eyebrow="03 · IAM INTELLIGENCE" title="Identity & Access Risk" desc="Detecting suspicious authentication, privilege and sensitive-resource activity." />
          <div className="feature-panel">
            <div className="feature-icon purple">♙</div>
            <div><span className="panel-label">IAM RISK</span><h3>{iam.toFixed(0)}/100 · {riskLabel(iam)}</h3><p>Correlate failed logins, new devices, new locations, off-hours access and privileged resource sensitivity.</p></div>
            <RiskPill score={iam} />
          </div>
        </section>

        <section id="incidents" className="section-anchor">
          <SectionHeader eyebrow="04 · INCIDENT INTELLIGENCE" title="Operational Situation Room" desc="Move from alert volume to predicted severity and customer impact." />
          <div className="incident-grid">
            <div className="incident-big"><span>ACTIVE INCIDENTS</span><strong>{dashboard.active_incidents ?? 258}</strong><small>Operational response queue</small></div>
            <div className="incident-level p1"><span>P1</span><strong>01</strong><small>Business critical</small></div>
            <div className="incident-level p2"><span>P2</span><strong>12</strong><small>High impact</small></div>
            <div className="incident-level p3"><span>P3</span><strong>245</strong><small>Standard response</small></div>
          </div>
        </section>

        <section id="aiops" className="section-anchor">
          <SectionHeader eyebrow="05 · AIOPS" title="Service Reliability Intelligence" desc="Correlate latency, error rate, availability and resource pressure with incident severity." />
          <div className="two-col">
            <div className="panel">
              <div className="panel-head"><div><span className="panel-label">7-DAY RISK TREND</span><h3>Technology posture</h3></div><RiskPill score={aiops} /></div>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={trend}>
                  <defs><linearGradient id="riskFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#38bdf8" stopOpacity=".35" /><stop offset="100%" stopColor="#38bdf8" stopOpacity="0" /></linearGradient></defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,.06)" vertical={false} />
                  <XAxis dataKey="day" stroke="#64748b" axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 100]} stroke="#64748b" axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: "#0b1425", border: "1px solid #24324a", borderRadius: 10 }} />
                  <Area type="monotone" dataKey="risk" stroke="#38bdf8" fill="url(#riskFill)" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="panel health-panel">
              <div className="health-row"><span>Service Availability</span><strong>99.92%</strong></div>
              <div className="health-row"><span>Latency</span><strong>184 ms</strong></div>
              <div className="health-row"><span>Error Rate</span><strong>1.8%</strong></div>
              <div className="health-row"><span>AIOps Risk</span><RiskPill score={aiops} /></div>
            </div>
          </div>
        </section>

        <section id="finops" className="section-anchor">
          <SectionHeader eyebrow="06 · FINOPS" title="Cloud Economics" desc="Technology cost intelligence connected to application and risk decisions." />
          <div className="finops-panel">
            <div><span className="panel-label">MONTHLY CLOUD SPEND</span><strong>${((dashboard.cloud_cost ?? 1223600) / 1000).toFixed(1)}K</strong><small>Across AWS / Azure workloads</small></div>
            <div className="cost-ring"><span>{finops}</span><small>Risk</small></div>
            <div><span className="panel-label">AI RECOMMENDATION</span><h3>Optimize non-critical capacity</h3><p>Prioritize savings where workload demand and business criticality are low.</p></div>
          </div>
        </section>

        <section id="cloud" className="section-anchor">
          <SectionHeader eyebrow="07 · CLOUD INTELLIGENCE" title="Multi-Cloud Posture" desc="Unified view across cloud security, cost and operational health." />
          <div className="cloud-grid">
            {[
              ["AWS", "Production workloads", "Healthy", "green"],
              ["Azure", "Enterprise workloads", "Monitored", "blue"],
              ["CNAPP", "Cloud security posture", "Action required", "red"],
              ["Kubernetes", "Container platform", "Healthy", "green"],
            ].map(([name, desc, status, tone]) => (
              <div className="cloud-card" key={name}><div className={`cloud-logo ${tone}`}>{name[0]}</div><div><strong>{name}</strong><span>{desc}</span></div><em className={tone}>{status}</em></div>
            ))}
          </div>
        </section>

        <section id="decision" className="section-anchor decision-section">
          <SectionHeader eyebrow="08 · AI DECISION CENTER" title="From Signal to Governed Action" desc="A decision pipeline designed for explainability, accountability and human approval." />
          <div className="decision-flow">
            {[
              ["01", "SIGNAL", "Technical telemetry"],
              ["02", "PREDICTION", "ML risk / severity"],
              ["03", "CORRELATION", "Cross-domain context"],
              ["04", "RECOMMEND", "AI + RAG"],
              ["05", "APPROVE", "Human governance"],
              ["06", "OUTCOME", "Action + KPI"],
            ].map(([num, title, desc], i) => (
              <div className="flow-step" key={num}><span>{num}</span><strong>{title}</strong><small>{desc}</small>{i < 5 && <b>→</b>}</div>
            ))}
          </div>
          <div className="decision-card">
            <div className="decision-status"><span className="status-dot" /> DECISION READY</div>
            <div className="decision-main">
              <div><span className="panel-label">DOMINANT RISK</span><h3>{correlation.dominant_risk ?? "Security"}</h3><p>{correlation.recommendation ?? fallback.correlation.recommendation}</p></div>
              <div className="decision-score"><strong>{tech.toFixed(1)}</strong><span>Technology Risk</span><RiskPill score={tech} /></div>
            </div>
          </div>
        </section>

        <section id="copilot" className="section-anchor">
          <SectionHeader eyebrow="09 · CTO COPILOT" title="Executive AI Copilot" desc="Ask a technology question. Receive a concise, risk-aware recommendation grounded in platform intelligence." />
          <div className="copilot">
            <div className="copilot-top"><div className="copilot-orb">✦</div><div><strong>CTO Copilot</strong><span>AI decision assistant · governance-aware</span></div><span className="ai-ready">● READY</span></div>
            <div className="ask-row">
              <input value={question} onChange={(e) => setQuestion(e.target.value)} onKeyDown={(e) => e.key === "Enter" && askCopilot()} />
              <button onClick={askCopilot}>{loading ? "Thinking..." : "Ask Copilot →"}</button>
            </div>
            <div className="suggestions">
              {["What should I worry about?", "What is driving technology risk?", "What should I remediate first?"].map(q => <button key={q} onClick={() => { setQuestion(q); }}>{q}</button>)}
            </div>
            {copilot && (
              <div className="copilot-answer">
                <div className="answer-label">AI RECOMMENDATION</div>
                <h3>{copilot.executive_summary || copilot.summary || "Executive recommendation ready."}</h3>
                <p>{copilot.recommendation || correlation.recommendation}</p>
                <div className="answer-meta"><span>Dominant risk · <b>{copilot.dominant_risk || correlation.dominant_risk}</b></span><span>CTO attention · <b>{copilot.cto_attention ? "YES" : "NO"}</b></span><span>Human approval · <b>REQUIRED</b></span></div>
                <div className="approval-row"><button className="approve" onClick={() => approve("APPROVED")}>✓ APPROVE ACTION</button><button className="reject" onClick={() => approve("REJECTED")}>× REJECT</button></div>
              </div>
            )}
          </div>
        </section>

        <section id="governance" className="section-anchor">
          <SectionHeader eyebrow="10 · GOVERNANCE & AUDIT" title="Human-in-the-Loop Control" desc="Consequential AI recommendations remain accountable, reviewable and auditable." />
          <div className="governance-grid">
            <div className="governance-card"><span className="panel-label">CONTROL MODEL</span><h3>Recommendation ≠ Automation</h3><p>AI proposes. An authorized human approves. The platform records the decision and expected outcome.</p></div>
            <div className="audit-card"><div className="audit-head"><span>RECENT AUDIT EVENTS</span><strong>{audit.length || 0}</strong></div>{audit.length ? audit.slice(-4).reverse().map((a, i) => <div className="audit-row" key={i}><span className="status-dot" /><div><strong>{a.decision || a.status || "Decision recorded"}</strong><small>{a.owner || "CTO"} · {a.action || "AI recommendation"}</small></div></div>) : <div className="empty-audit">No approval events yet. Use CTO Copilot to create one.</div>}</div>
          </div>
        </section>

        <footer>
          <span>FINTECH AI TECHNOLOGY INTELLIGENCE & AUTOMATION PLATFORM</span>
          <span>POC · CTO / SECURITY ARCHITECT · AI GOVERNANCE</span>
        </footer>
      </main>

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}

export default App;
