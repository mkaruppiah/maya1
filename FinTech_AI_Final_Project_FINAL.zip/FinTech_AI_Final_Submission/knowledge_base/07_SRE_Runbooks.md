# SRE Runbooks
Golden signals: latency, traffic, errors, saturation.
Track availability, SLIs, SLOs, error budgets, MTTR, incident frequency, and dependency health.
RCA flow:
service/customer journey -> SLO impact -> baseline comparison -> correlated evidence -> root-cause hypotheses -> recommended mitigation -> validation metric.
AI-generated RCA remains a hypothesis until validated.
