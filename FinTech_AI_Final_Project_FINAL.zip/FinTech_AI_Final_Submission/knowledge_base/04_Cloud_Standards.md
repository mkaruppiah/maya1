# Cloud Standards
AWS/Azure controls:
- Federated identity and least privilege.
- Network segmentation and controlled ingress/egress.
- Private connectivity for sensitive services where appropriate.
- Centralized cloud, identity, network, and workload logging.
- Encryption and centrally managed keys/secrets.
- Hardened VM, container, Kubernetes, serverless, database, and storage configurations.
