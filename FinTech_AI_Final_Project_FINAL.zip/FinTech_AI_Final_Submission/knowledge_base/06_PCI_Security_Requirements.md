# PCI / Payment Security RAG Guide
Retrieval topics:
network security, secure configurations, account-data protection, encryption, malware protection, secure development, access restriction, authentication, logging, monitoring, testing, and security policies.

This is a synthetic project guide, not the authoritative PCI DSS standard. Production compliance decisions must use current official PCI SSC material and organizational compliance guidance.
