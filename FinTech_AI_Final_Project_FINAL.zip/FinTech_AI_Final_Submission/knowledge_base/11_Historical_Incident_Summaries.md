# Synthetic Historical Incident Summaries
## INC-001 Payment API Latency
P1; high customer impact. Evidence: recent release and database saturation. Root cause: connection-pool configuration. Outcome: approved configuration correction restored baseline.

## INC-002 Authentication Failures
P2; medium customer impact. Evidence: identity-provider configuration change. Root cause: incorrect authentication policy. Outcome: approved configuration correction.

## INC-003 Cloud Cost Anomaly
P3; low customer impact. Evidence: new analytics workload and uncontrolled scaling. Root cause: missing resource limits. Outcome: resource policies and budgets introduced.
