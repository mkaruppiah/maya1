# Disaster Recovery Procedures
Define critical services, dependencies, RTO, RPO, backups, recovery ownership, recovery environment, communications, and testing.
Flow: declare -> assess -> authorize -> recover -> validate service/data integrity -> communicate -> document outcomes.
