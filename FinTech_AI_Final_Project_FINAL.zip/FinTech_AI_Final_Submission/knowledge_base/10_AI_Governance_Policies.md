# AI Governance Policies
Principles: accountability, transparency, security, privacy, human oversight, traceability, evaluation, controlled automation.
- Record important AI recommendations.
- Protect sensitive data.
- Evaluate model and retrieval quality.
- Require human approval for consequential actions.
- Agentic AI must use bounded permissions, explicit tools, audit logs, approval gates, and failure handling.
- RAG should retrieve only approved sources and preserve source metadata.
