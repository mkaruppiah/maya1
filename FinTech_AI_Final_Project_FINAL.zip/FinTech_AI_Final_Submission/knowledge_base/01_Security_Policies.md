# Security Policies
Purpose: baseline security policy for the synthetic FinTech AI POC.
- Least privilege and separation of duties.
- MFA for privileged access.
- Encrypt sensitive data in transit and at rest.
- Centralize security logging and audit evidence.
- Store secrets in approved secret-management systems.
- Prioritize findings using severity, exploitability, exposure, and business criticality.
- Consequential production actions require authorized human approval.
