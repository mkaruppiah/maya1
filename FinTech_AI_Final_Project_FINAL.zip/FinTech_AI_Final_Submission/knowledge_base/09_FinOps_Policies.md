# FinOps Policies
Track actual spend, budgets, variance, forecasts, idle/oversized resources, unused storage, commitments, unit cost, and anomalies.
Recommendations must balance savings with security, reliability, customer impact, engineering effort, and architecture constraints.
CTO output: savings + effort + risk + business impact + expected KPI.
