# FinTech CTO RAG Knowledge Base
Synthetic POC documents for RAG/LLM/Agentic AI development.

Recommended chunk metadata:
document_id, title, category, version, owner, classification, effective_date, source, chunk_id.

RAG flow:
Documents -> parse -> chunk -> embeddings -> pgvector -> retrieve -> optional rerank -> LLM -> grounded answer -> evidence/source metadata -> audit.

These are synthetic templates, not official organizational, legal, regulatory, or PCI policies. Replace/supplement them with approved authoritative documents for production.
