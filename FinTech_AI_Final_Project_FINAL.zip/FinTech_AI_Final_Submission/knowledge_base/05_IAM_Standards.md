# IAM Standards
Zero Trust principles:
- Verify identity and authorization explicitly.
- MFA for privileged users.
- Time-bound privileged access where practical.
- Periodic access reviews.
- Disable unnecessary or stale identities.
- Separate human and workload identities.
- Detect abnormal privilege use, unusual authentication, dormant privileged accounts, and risky service identities.
