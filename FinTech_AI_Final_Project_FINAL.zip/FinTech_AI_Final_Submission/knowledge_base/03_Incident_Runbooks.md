# Incident Runbooks
P1/P2 workflow:
1. Confirm severity and affected business service.
2. Assign incident leadership.
3. Record customer impact and start time.
4. Correlate logs, metrics, traces, security, IAM, deployments, and dependencies.
5. Rank root-cause hypotheses.
6. Recommend the lowest-risk reversible response.
7. Require authorization for high-impact production action.
8. Validate recovery and record lessons learned.
