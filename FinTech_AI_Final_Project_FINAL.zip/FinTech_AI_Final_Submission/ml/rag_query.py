from pathlib import Path
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

ROOT = Path(__file__).resolve().parents[1]
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
store = Chroma(persist_directory=str(ROOT / "ml" / "rag_vector_db"), embedding_function=embeddings)
query = "What should happen when there is a high-risk security finding on an internet-facing production asset?"
for i, doc in enumerate(store.similarity_search(query, k=3), 1):
    print(f"\nRESULT {i}\n{doc.page_content}\nSOURCE: {doc.metadata.get('source')}")
