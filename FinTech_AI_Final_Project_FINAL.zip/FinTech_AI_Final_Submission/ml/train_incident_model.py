from pathlib import Path
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "historical_incidents_300.csv")
map_risk = {"Low":2.0,"Medium":5.0,"High":8.0,"Critical":10.0}
map_impact = {"Low":0.1,"Medium":0.5,"High":1.0}
df["security_risk_num"] = df["security_risk"].map(map_risk).fillna(0)
df["iam_risk_num"] = df["iam_risk"].map(map_risk).fillna(0)
df["customer_impact_num"] = df["customer_impact"].map(map_impact).fillna(0)
df["error_rate"] = 0.0
features = ["security_risk_num","iam_risk_num","latency_ms","customer_impact_num","error_rate"]
X=df[features]
y=df["severity"].astype(str)
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
model=RandomForestClassifier(n_estimators=200,max_depth=10,random_state=42,class_weight="balanced")
model.fit(X_train,y_train)
pred=model.predict(X_test)
print("Accuracy:",round(accuracy_score(y_test,pred),4))
print(classification_report(y_test,pred,zero_division=0))
print("Confusion matrix:\n",confusion_matrix(y_test,pred))
print("Feature importance:",dict(zip(features,model.feature_importances_)))
joblib.dump(model,ROOT/"ml"/"incident_severity_model.pkl")
print("Saved:",ROOT/"ml"/"incident_severity_model.pkl")
