# FinTech AI Terraform Modules

Starter IaC for the FinTech AI POC: VPC/subnets, security groups, ECR, ECS Fargate FastAPI, ALB, RDS PostgreSQL, S3 AI data, S3/CloudFront React frontend, IAM, and CloudWatch.

## Run
cd environments/dev
terraform init
terraform fmt -recursive
terraform validate
terraform plan
terraform apply

## Important
This is a POC starter. ECS currently uses a public IP because NAT gateways/VPC endpoints are intentionally omitted to keep the starter smaller. Before production, use private egress/NAT or VPC endpoints, ALB HTTPS/ACM, WAF, remote encrypted Terraform state/locking, stronger least-privilege IAM, KMS CMKs where required, alarms, RDS deletion protection/final snapshots, secrets injection, and CI/CD security gates.

