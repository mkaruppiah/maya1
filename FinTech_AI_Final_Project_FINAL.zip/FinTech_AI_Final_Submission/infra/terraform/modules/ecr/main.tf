resource "aws_ecr_repository" "backend" {
 name="${var.project}-${var.environment}-backend"
 image_scanning_configuration { scan_on_push=true }
}
