resource "aws_s3_bucket" "ai" { bucket_prefix="${var.project}-${var.environment}-ai-" }
resource "aws_s3_bucket_public_access_block" "ai" {
 bucket=aws_s3_bucket.ai.id
 block_public_acls=true
 block_public_policy=true
 ignore_public_acls=true
 restrict_public_buckets=true
}
resource "aws_s3_bucket_server_side_encryption_configuration" "ai" {
 bucket=aws_s3_bucket.ai.id
 rule { apply_server_side_encryption_by_default { sse_algorithm="AES256" } }
}
