output "bucket_name" { value=aws_s3_bucket.ai.bucket }
output "bucket_arn" { value=aws_s3_bucket.ai.arn }
