variable "project" { type=string }
variable "environment" { type=string }
variable "subnet_ids" { type=list(string) }
variable "security_group_id" { type=string }
variable "instance_class" { type=string default="db.t4g.micro" }
