resource "aws_db_subnet_group" "this" {
 name="${var.project}-${var.environment}-db"; subnet_ids=var.subnet_ids
}
resource "aws_db_instance" "this" {
 identifier="${var.project}-${var.environment}"
 engine="postgres"
 instance_class=var.instance_class
 allocated_storage=20
 storage_encrypted=true
 db_name="fintechai"
 username="fintechadmin"
 manage_master_user_password=true
 db_subnet_group_name=aws_db_subnet_group.this.name
 vpc_security_group_ids=[var.security_group_id]
 publicly_accessible=false
 backup_retention_period=7
 skip_final_snapshot=true
}
