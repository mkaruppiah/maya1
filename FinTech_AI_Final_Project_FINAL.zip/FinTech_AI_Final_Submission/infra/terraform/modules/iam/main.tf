data "aws_iam_policy_document" "assume" {
 statement {
  actions=["sts:AssumeRole"]
  principals { type="Service" identifiers=["ecs-tasks.amazonaws.com"] }
 }
}
resource "aws_iam_role" "execution" {
 name="${var.project}-${var.environment}-ecs-execution"
 assume_role_policy=data.aws_iam_policy_document.assume.json
}
resource "aws_iam_role_policy_attachment" "execution" {
 role=aws_iam_role.execution.name
 policy_arn="arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}
resource "aws_iam_role" "task" {
 name="${var.project}-${var.environment}-backend-task"
 assume_role_policy=data.aws_iam_policy_document.assume.json
}
data "aws_iam_policy_document" "task" {
 statement {
  actions=["s3:GetObject","s3:ListBucket"]
  resources=[var.bucket_arn,"${var.bucket_arn}/*"]
 }
}
resource "aws_iam_role_policy" "task" {
 role=aws_iam_role.task.id
 policy=data.aws_iam_policy_document.task.json
}
