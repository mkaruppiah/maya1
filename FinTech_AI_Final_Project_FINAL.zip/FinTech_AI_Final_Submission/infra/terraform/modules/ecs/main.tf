resource "aws_ecs_cluster" "this" { name="${var.project}-${var.environment}" }
resource "aws_ecs_task_definition" "api" {
 family="${var.project}-${var.environment}-backend"
 requires_compatibilities=["FARGATE"]
 network_mode="awsvpc"; cpu="512"; memory="1024"
 execution_role_arn=var.execution_role_arn
 task_role_arn=var.task_role_arn
 container_definitions=jsonencode([{
  name="fastapi"; image="${var.image_url}:${var.image_tag}"; essential=true
  portMappings=[{containerPort=8000,protocol="tcp"}]
  environment=[{name="AI_DATA_BUCKET",value=var.ai_bucket}]
  logConfiguration={logDriver="awslogs",options={
   awslogs-group=var.log_group_name,awslogs-region=var.aws_region,awslogs-stream-prefix="api"
  }}
 }])
}
resource "aws_ecs_service" "api" {
 name="${var.project}-${var.environment}-backend"
 cluster=aws_ecs_cluster.this.id
 task_definition=aws_ecs_task_definition.api.arn
 desired_count=2; launch_type="FARGATE"
 network_configuration {
  subnets=var.subnet_ids
  security_groups=[var.security_group_id]
  assign_public_ip=true
 }
 load_balancer {
  target_group_arn=var.target_group_arn
  container_name="fastapi"; container_port=8000
 }
}
