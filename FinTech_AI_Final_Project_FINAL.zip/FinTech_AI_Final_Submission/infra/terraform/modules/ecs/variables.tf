variable "project" { type=string }
variable "environment" { type=string }
variable "aws_region" { type=string }
variable "image_url" { type=string }
variable "image_tag" { type=string default="latest" }
variable "execution_role_arn" { type=string }
variable "task_role_arn" { type=string }
variable "subnet_ids" { type=list(string) }
variable "security_group_id" { type=string }
variable "target_group_arn" { type=string }
variable "log_group_name" { type=string }
variable "ai_bucket" { type=string }
