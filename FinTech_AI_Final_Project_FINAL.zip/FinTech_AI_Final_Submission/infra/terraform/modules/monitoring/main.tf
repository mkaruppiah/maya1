resource "aws_cloudwatch_log_group" "backend" {
 name="/${var.project}/${var.environment}/backend"
 retention_in_days=30
}
