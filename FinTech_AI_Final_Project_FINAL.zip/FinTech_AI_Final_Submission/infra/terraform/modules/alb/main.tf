resource "aws_lb" "this" {
 name="${var.project}-${var.environment}-alb"
 load_balancer_type="application"
 subnets=var.subnet_ids
 security_groups=[var.security_group_id]
}
resource "aws_lb_target_group" "api" {
 name="${var.project}-${var.environment}-api"
 port=8000; protocol="HTTP"; vpc_id=var.vpc_id; target_type="ip"
 health_check { path="/health" matcher="200" }
}
resource "aws_lb_listener" "http" {
 load_balancer_arn=aws_lb.this.arn; port=80; protocol="HTTP"
 default_action { type="forward"; target_group_arn=aws_lb_target_group.api.arn }
}
