variable "aws_region" { type=string default="us-east-1" }
variable "project" { type=string default="fintech-ai" }
variable "environment" { type=string default="dev" }
variable "vpc_cidr" { type=string default="10.20.0.0/16" }
variable "backend_image_tag" { type=string default="latest" }
