output "api_dns" { value=module.alb.dns_name }
output "frontend_domain" { value=module.frontend.cloudfront_domain }
output "frontend_bucket" { value=module.frontend.bucket_name }
output "backend_ecr" { value=module.ecr.repository_url }
output "database_endpoint" { value=module.database.endpoint sensitive=true }
output "ai_data_bucket" { value=module.storage.bucket_name }
