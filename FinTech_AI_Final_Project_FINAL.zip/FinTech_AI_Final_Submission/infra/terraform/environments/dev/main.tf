provider "aws" { region=var.aws_region }
module "networking" { source="../../modules/networking"; project=var.project; environment=var.environment; vpc_cidr=var.vpc_cidr }
module "security" { source="../../modules/security"; project=var.project; environment=var.environment; vpc_id=module.networking.vpc_id }
module "storage" { source="../../modules/storage"; project=var.project; environment=var.environment }
module "ecr" { source="../../modules/ecr"; project=var.project; environment=var.environment }
module "iam" { source="../../modules/iam"; project=var.project; environment=var.environment; bucket_arn=module.storage.bucket_arn }
module "monitoring" { source="../../modules/monitoring"; project=var.project; environment=var.environment }
module "alb" { source="../../modules/alb"; project=var.project; environment=var.environment; vpc_id=module.networking.vpc_id; subnet_ids=module.networking.public_subnets; security_group_id=module.security.alb_sg_id }
module "database" { source="../../modules/database"; project=var.project; environment=var.environment; subnet_ids=module.networking.db_subnets; security_group_id=module.security.db_sg_id }
module "frontend" { source="../../modules/frontend"; project=var.project; environment=var.environment }
module "ecs" {
 source="../../modules/ecs"; project=var.project; environment=var.environment; aws_region=var.aws_region
 image_url=module.ecr.repository_url; image_tag=var.backend_image_tag
 execution_role_arn=module.iam.execution_role_arn; task_role_arn=module.iam.task_role_arn
 subnet_ids=module.networking.app_subnets; security_group_id=module.security.backend_sg_id
 target_group_arn=module.alb.target_group_arn; log_group_name=module.monitoring.log_group_name
 ai_bucket=module.storage.bucket_name
}
